// CONSTANTS

// BROWSER compatibility
const BROWSER = chrome || BROWSER;
const BROWSER_STRING = chrome ? 'chrome' : 'browser';
// const STORAGE = chrome.storage.sync || chrome.storage.local;

// a11y.css web extension-specific constants
const EXTENSION_PREFIX = 'a11ycss_';
